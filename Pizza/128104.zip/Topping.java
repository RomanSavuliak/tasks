
public class Topping {
    private String topping;

    public Topping(String topping) {
        this.topping = topping;
    }

    public String getTopping() {
        return topping;
    }

    public void setTopping(String topping) {
        this.topping = topping;
    }
}
